<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
Route::view('/', 'index')->name('home');   // يعرض resources/views/index.blade.php


Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});
use App\Http\Middleware\AdminOnly;
use App\Http\Controllers\TripRequestController;

Route::middleware(['auth', AdminOnly::class])->group(function () {
    Route::patch('/admin/requests/{id}/approve', [TripRequestController::class, 'approve'])
        ->name('admin.requests.approve');
    Route::patch('/admin/requests/{id}/reject', [TripRequestController::class, 'reject'])
        ->name('admin.requests.reject');
    Route::delete('/admin/requests/{id}', [TripRequestController::class, 'destroy'])
        ->name('admin.requests.destroy');
});

require __DIR__.'/auth.php';
