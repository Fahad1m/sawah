<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TripController;

Route::get('/trips', [TripController::class, 'apiIndex']);   // JSON + Pagination

use App\Http\Controllers\TripRequestController;

Route::get('/requests', [TripRequestController::class, 'index']);
Route::get('/requests/mine', [TripRequestController::class, 'mine']);
Route::post('/requests', [TripRequestController::class, 'store']);
Route::patch('/requests/{id}/approve', [TripRequestController::class, 'approve']);
Route::patch('/requests/{id}/reject', [TripRequestController::class, 'reject']);
Route::delete('/requests/{id}', [TripRequestController::class, 'destroy']);
