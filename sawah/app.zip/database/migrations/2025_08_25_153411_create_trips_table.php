<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('trips', function (Blueprint $table) {
            $table->id();
            $table->string('destination'); // الوجهة
            $table->text('description');   // وصف الرحلة
            $table->integer('price');      // السعر
            $table->integer('duration');   // المدة (أيام)
            $table->float('rating')->default(0); // التقييم
            $table->string('image')->nullable(); // صورة الرحلة
            $table->json('features')->nullable(); // المميزات (JSON)
            $table->timestamps();
        });
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('trips');
    }
};
