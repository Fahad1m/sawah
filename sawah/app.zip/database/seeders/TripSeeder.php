<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Trip;

class TripSeeder extends Seeder
{
    public function run(): void
    {
        Trip::create([
            'destination' => 'إسطنبول، تركيا',
            'description' => 'جولة في المدينة التي تربط بين قارتي آسيا وأوروبا، مع زيارة آيا صوفيا والمسجد الأزرق',
            'price' => 3200,
            'duration' => 7,
            'rating' => 4.9,
            'image' => 'https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?...',
            'features' => ['فندق 5 نجوم', 'جولات يومية', 'تذاكر دخول للمعالم']
        ]);

        Trip::create([
            'destination' => 'دبي، الإمارات',
            'description' => 'تجربة فاخرة في مدينة دبي مع زيارة برج خليفة ونخلة جميرا',
            'price' => 4500,
            'duration' => 4,
            'rating' => 4.7,
            'image' => 'https://images.unsplash.com/photo-1518684079-3c830dcef090?...',
            'features' => ['إقامة فاخرة', 'تذاكر برج خليفة', 'رحلة سفاري صحراوية']
        ]);
    }
}
