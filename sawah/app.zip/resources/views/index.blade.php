<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  {{-- CSRF + تمرير حالة المستخدم --}}
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <script>
    window.laravelUser = @json(auth()->user());
  </script>

  <title>سُوّاح | موقع سياحي</title>

  {{-- الخطوط والأيقونات --}}
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  {{-- ملفاتك --}}
  <link rel="stylesheet" href="{{ asset('styles.css') }}">
  <script src="{{ asset('script.js') }}" defer></script>
</head>
<body>

  {{-- الهيدر --}}
  <header class="header">
    <div class="container">
      <nav class="nav">
        <a href="javascript:void(0)" class="logo" onclick="showSection('home')">
          <i class="fa-solid fa-plane-departure"></i> سُوّاح
        </a>

        <ul class="nav-links">
          <li><a href="javascript:void(0)" onclick="showSection('home')">الرئيسية</a></li>
          <li><a href="javascript:void(0)" onclick="showSection('requests')">الطلبات</a></li>
          <li><a href="javascript:void(0)" onclick="showSection('recommendations')">التوصيات</a></li>
        </ul>

        {{-- أزرار/قائمة الحساب بإدارة Laravel Breeze --}}
        @auth
          <div id="authButtons" class="auth-buttons" style="display:none;"></div>

          <div id="userMenu" class="auth-buttons" style="display:flex;">
            <span id="welcomeText">مرحباً، {{ auth()->user()->name }}</span>
            @if(auth()->user()->is_admin)
              <a id="adminBtn" class="btn btn-secondary" onclick="showSection('admin')">لوحة التحكم</a>
            @endif
            <form method="POST" action="{{ route('logout') }}" style="display:inline;">
              @csrf
              <button class="btn btn-primary" type="submit">تسجيل الخروج</button>
            </form>
          </div>

          <div id="userWelcome" class="welcome-section" style="display:flex;">
            <div id="welcomeMessage" class="welcome-message">مرحباً، {{ auth()->user()->name }}</div>
          </div>
        @else
          <div id="authButtons" class="auth-buttons" style="display:flex;">
            <a class="btn btn-secondary" href="{{ route('login') }}">تسجيل الدخول</a>
            <a class="btn btn-primary"   href="{{ route('register') }}">إنشاء حساب</a>
          </div>

          <div id="userMenu" class="auth-buttons" style="display:none;"></div>
          <div id="userWelcome" class="welcome-section" style="display:none;">
            <div id="welcomeMessage" class="welcome-message"></div>
          </div>
        @endauth
      </nav>
    </div>
  </header>

  <main class="main-content">
    {{-- القسم: الرئيسية --}}
    <section id="home" class="section active">
      <div class="hero">
        <div class="hero-content">
          <h1>اكتشف وجهتك القادمة</h1>
          <p>أفضل العروض على الرحلات والجولات السياحية حول العالم — احجز رحلتك الآن.</p>

          <div class="search-container">
            <div class="search-box">
              <input id="searchTrips" type="text" placeholder="ابحث عن وجهة…">
              <select id="filterDestination2">
                <option value="">كل الوجهات</option>
              </select>
              <select id="filterPrice2">
                <option value="">كل الأسعار</option>
                <option value="low">أقل من 1000</option>
                <option value="medium">1000 - 3000</option>
                <option value="high">أكثر من 3000</option>
              </select>
              <button type="button" onclick="filterTrips()">تصفية</button>
            </div>
          </div>
        </div>
      </div>

      <div class="container">
        <h2 class="mt-4">عروض مميزة</h2>
        <div id="featuredTrips" class="trips-grid"></div>

        <h2 class="mt-4">كل الرحلات</h2>
        <div id="allTrips" class="trips-grid"></div>
      </div>
    </section>

    {{-- القسم: طلبات الرحلات --}}
    <section id="requests" class="section">
      <div class="container">
        <h2>طلب رحلة مخصصة</h2>

        <div class="form-container">
          <form id="tripRequestForm">
            <div class="form-group">
              <label>الوجهة</label>
              <input id="requestDestination" required>
            </div>
            <div class="form-group">
              <label>تاريخ السفر</label>
              <input id="requestDate" type="date" required>
            </div>
            <div class="form-group">
              <label>عدد الأشخاص</label>
              <input id="requestPeople" type="number" min="1" value="1" required>
            </div>
            <div class="form-group">
              <label>الميزانية (ريال)</label>
              <input id="requestBudget" type="number" min="0" required>
            </div>
            <div class="form-group">
              <label>تفاصيل إضافية</label>
              <textarea id="requestDetails" placeholder="مثلاً: شهر عسل، برنامج للأطفال،…"></textarea>
            </div>
            <button class="btn btn-primary" type="submit">إرسال الطلب</button>
          </form>
        </div>

        <h3 class="mt-4">طلباتي السابقة</h3>
        <div id="userRequests"></div>
      </div>
    </section>

    {{-- القسم: التوصيات --}}
    <section id="recommendations" class="section">
      <div class="container">
        <h2>شاركنا توصياتك</h2>

        <div class="form-container">
          <form id="recommendationForm">
            <div class="form-group">
              <label>المكان</label>
              <input id="recPlace" required>
            </div>
            <div class="form-group">
              <label>التقييم</label>
              <select id="recRating">
                <option value="5">★★★★★</option>
                <option value="4">★★★★☆</option>
                <option value="3">★★★☆☆</option>
                <option value="2">★★☆☆☆</option>
                <option value="1">★☆☆☆☆</option>
              </select>
            </div>
            <div class="form-group">
              <label>نص التوصية</label>
              <textarea id="recText" required></textarea>
            </div>
            <button class="btn btn-primary" type="submit">إضافة التوصية</button>
          </form>
        </div>

        <div id="recommendationsList" class="recommendations"></div>
      </div>
    </section>

    {{-- القسم: لوحة التحكم (أدمن) --}}
    <section id="admin" class="section">
      <div class="container">
        <h2>لوحة التحكم</h2>

        <div class="stats-grid">
          <div class="stat-card">
            <div id="totalTrips" class="stat-number">0</div>
            <div class="stat-label">الرحلات</div>
          </div>
          <div class="stat-card">
            <div id="totalRequests" class="stat-number">0</div>
            <div class="stat-label">الطلبات</div>
          </div>
          <div class="stat-card">
            <div id="totalUsers" class="stat-number">0</div>
            <div class="stat-label">المستخدمون</div>
          </div>
          <div class="stat-card">
            <div id="totalRecommendations" class="stat-number">0</div>
            <div class="stat-label">التوصيات</div>
          </div>
        </div>

        <div class="admin-tabs">
          <button class="admin-tab active" onclick="showAdminTab('trips')">الرحلات</button>
          <button class="admin-tab" onclick="showAdminTab('requests')">الطلبات</button>
          <button class="admin-tab" onclick="showAdminTab('users')">المستخدمون</button>
          <button class="admin-tab" onclick="showAdminTab('recommendations')">التوصيات</button>
        </div>

        <div id="adminTrips" class="admin-content active">
          <div style="margin-bottom: 1rem;">
            <button class="btn btn-primary" onclick="showAddTripModal()">+ إضافة رحلة</button>
          </div>
          <table class="data-table">
            <thead>
              <tr><th>الوجهة</th><th>السعر</th><th>التقييم</th><th>إجراءات</th></tr>
            </thead>
            <tbody id="adminTripsTable"></tbody>
          </table>
        </div>

        <div id="adminRequests" class="admin-content">
          <table class="data-table">
            <thead>
              <tr><th>المستخدم</th><th>الوجهة</th><th>التاريخ</th><th>الحالة</th><th>إجراءات</th></tr>
            </thead>
            <tbody id="adminRequestsTable"></tbody>
          </table>
        </div>

        <div id="adminUsers" class="admin-content">
          <table class="data-table">
            <thead>
              <tr><th>الاسم</th><th>البريد</th><th>النوع</th><th>تاريخ الانضمام</th><th>إجراءات</th></tr>
            </thead>
            <tbody id="adminUsersTable"></tbody>
          </table>
        </div>

        <div id="adminRecommendations" class="admin-content">
          <table class="data-table">
            <thead>
              <tr><th>المستخدم</th><th>المكان</th><th>التقييم</th><th>التاريخ</th><th>إجراءات</th></tr>
            </thead>
            <tbody id="adminRecommendationsTable"></tbody>
          </table>
        </div>
      </div>
    </section>
  </main>

  {{-- مودال إضافة رحلة (يستخدمه الأدمن عبر JS) --}}
  <div id="addTripModal" class="modal">
    <div class="modal-content">
      <button class="modal-close" onclick="closeModal('addTripModal')">×</button>
      <h3 style="margin-bottom:1rem;">إضافة رحلة</h3>
      <form id="addTripForm">
        <div class="form-group"><label>الوجهة</label><input id="tripDestination" required></div>
        <div class="form-group"><label>الوصف</label><textarea id="tripDescription"></textarea></div>
        <div class="form-group"><label>السعر</label><input id="tripPrice" type="number" required></div>
        <div class="form-group"><label>المدة (أيام)</label><input id="tripDuration" type="number" required></div>
        <div class="form-group"><label>صورة (رابط)</label><input id="tripImage" type="url" placeholder="https://..."></div>
        <div class="form-group"><label>المزايا (مفصولة بفواصل)</label><input id="tripFeatures" placeholder="فندق 5 نجوم, جولات, ..."></div>
        <button class="btn btn-primary" type="submit">إضافة</button>
      </form>
    </div>
  </div>

  {{-- نُبقي مودالات الدخول/التسجيل لأجل توافق الـ JS (لن تُستخدم مع Breeze) --}}
  <div id="loginModal" class="modal">
    <div class="modal-content">
      <button class="modal-close" onclick="closeModal('loginModal')">×</button>
      <h3>تسجيل الدخول</h3>
      <p>يتم تسجيل الدخول عبر الصفحة <a href="{{ route('login') }}">/login</a></p>
      <form id="loginForm">
        <div class="form-group"><label>البريد</label><input id="loginEmail" type="email" disabled></div>
        <div class="form-group"><label>كلمة المرور</label><input id="loginPassword" type="password" disabled></div>
        <button class="btn btn-primary" type="submit" disabled>دخول</button>
      </form>
    </div>
  </div>

  <div id="registerModal" class="modal">
    <div class="modal-content">
      <button class="modal-close" onclick="closeModal('registerModal')">×</button>
      <h3>إنشاء حساب</h3>
      <p>أنشئ حساباً عبر الصفحة <a href="{{ route('register') }}">/register</a></p>
      <form id="registerForm">
        <div class="form-group"><label>الاسم</label><input id="registerName" disabled></div>
        <div class="form-group"><label>البريد</label><input id="registerEmail" type="email" disabled></div>
        <div class="form-group"><label>كلمة المرور</label><input id="registerPassword" type="password" disabled></div>
        <div class="form-group"><label>تأكيد كلمة المرور</label><input id="registerConfirmPassword" type="password" disabled></div>
        <button class="btn btn-primary" type="submit" disabled>تسجيل</button>
      </form>
    </div>
  </div>

  {{-- نعيد توجيه دوال فتح المودالات إلى صفحات Breeze --}}
  <script>
    window.addEventListener('DOMContentLoaded', function () {
      window.showLoginModal = function(){ window.location.href = "{{ route('login') }}"; };
      window.showRegisterModal = function(){ window.location.href = "{{ route('register') }}"; };
    });
  </script>
</body>
</html>
