<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Trip extends Model
{
protected $fillable = ['destination','description','price','duration','rating','image','features'];
protected $casts    = ['features' => 'array'];

}

