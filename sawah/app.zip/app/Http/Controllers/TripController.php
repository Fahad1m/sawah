<?php

namespace App\Http\Controllers;

use App\Models\Trip;
use Illuminate\Http\Request;

class TripController extends Controller
{

    public function index()
    {
        return view("index");
    }

public function apiIndex()
{
    $trips = Trip::select('id','destination','description','price','duration','rating','image','features')
        ->latest()
        ->paginate(12);

    return response()->json(
        $trips,
        200,
        [],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
}

    public function store(Request $request)
    {
        $trip = Trip::create($request->all());
        return response()->json($trip, 201);
    }


    public function show($id)
    {
        return response()->json(Trip::findOrFail($id));
    }


    public function update(Request $request, $id)
    {
        $trip = Trip::findOrFail($id);
        $trip->update($request->all());
        return response()->json($trip);
    }


    public function destroy($id)
    {
        Trip::findOrFail($id)->delete();
        return response()->json(null, 204);
    }
}
